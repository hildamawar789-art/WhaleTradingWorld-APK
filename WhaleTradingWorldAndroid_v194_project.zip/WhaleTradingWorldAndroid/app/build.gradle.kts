plugins { id("com.android.application") }

android { namespace = "com.whaletradingworld.mobile"; compileSdk = 36
    defaultConfig { applicationId = "com.whaletradingworld.mobile"; minSdk = 26; targetSdk = 36; versionCode = 194; versionName = "1.94" }
    buildTypes { release { isMinifyEnabled = false; isShrinkResources = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}

dependencies { implementation("androidx.webkit:webkit:1.14.0") }
