# Whale Trading World currently does not require custom R8 rules.
