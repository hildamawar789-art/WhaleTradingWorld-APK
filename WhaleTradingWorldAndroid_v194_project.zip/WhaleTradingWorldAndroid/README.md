# Whale Trading World — Android v1.94

This project packages `whale_trading_world_v194_max_buy_fix.html` as a local Android WebView app.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK platform/build tools requested by the project.
3. Run on a physical Android device or emulator.
4. Build > Generate App Bundles or APKs > Generate APKs.

The HTML is bundled inside `app/src/main/assets/index.html`, so the game UI itself is local. Internet permission remains enabled because the current game contains remote image/map resources.

## Performance intent
- Hardware accelerated WebView.
- Portrait-first mobile shell.
- Local asset loading through `WebViewAssetLoader`.
- DOM storage + IndexedDB enabled for the game's save engine.
- No second WebView is created.

Note: the APK wrapper alone does not eliminate simulation/rendering lag. The next mobile-performance pass should reduce unnecessary DOM redraws, orderbook rebuilds, chart frequency, tape history, and background simulation work.
